/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

// Import statements in Polymer 3.0 can now use package names.
// polymer-element.js now exports PolymerElement instead of Element,
// so no need to change the symbol. 
import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

//Form Input and validations
import '@polymer/paper-checkbox/paper-checkbox.js';
import '@polymer/paper-input/paper-input.js';
import '@polymer/paper-button/paper-button.js';
import '@polymer/iron-form/iron-form.js'; 
import '@polymer/app-route/app-location.js';
import '@polymer/app-route/app-route.js';

class LoginPage extends PolymerElement {
  static get template () {
    // Template getter must return an instance of HTMLTemplateElement.
    // The html helper function makes this easy.
    return html`
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/style_v1.css">
    <script src="node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
    <app-location route='{{route}}'></app-location>
    
    <app-route
    route="{{route}}"
    pattern="/:view"
    data="{{routeData}}"
    tail="{{subroute}}"></app-route>
	
    <div id="login">
        <div class="container">
            <div id="login-row" class="row justify-content-center align-items-center">
                <div id="login-column" class="col-md-6">
                    <div id="login-box" class="col-md-12">
                      
                    <p class="til_c1">Welcome To Polymer E-commerce.. please login to continue</p>
                    
                    <iron-form id='myForm'>
                  <form  is="iron-form" id="login" name ="login" method="post" action="/" class="loginform_c1">
                    <paper-input auto-validate required error-message='Please Enter Your Username' type="text" name="l_username" label="Username" id="l_username"></paper-input>
                    <paper-input auto-validate required  error-message='Please Enter Your Password' type="password" name="l_password" label="Password" id="l_password"></paper-input>
                    <a href='/product-list'> <paper-button class="submit_c1"  on-click='validate'>Submit</paper-button>
                    </a>
                  </form>
                  </iron-form>

                  


                    </div>
                </div>
            </div>
        </div>
    </div>
	

    `;
  }

  ready(){
    super.ready();
    this.$.miInput.addEventListener("input", function (e) {
      this.validate(e); 
    }.bind(this));
  }

  
  validate(e){
    e.preventDefault();
    this.$.myForm.validate();
    this.set('route.path', '/product-list'); 
  }


  changeRoute () {
    this.set('route.path', '/sports-list')
  }


}













// Register the element with the browser.
customElements.define('login-page', LoginPage);
