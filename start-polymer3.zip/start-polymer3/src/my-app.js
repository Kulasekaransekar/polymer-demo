/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */


 // Import Polymer Elements 
import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import { setPassiveTouchGestures, setRootPath } from '@polymer/polymer/lib/utils/settings.js';
import '@polymer/app-layout/app-drawer/app-drawer.js';
import '@polymer/app-layout/app-drawer-layout/app-drawer-layout.js';
import '@polymer/app-layout/app-header/app-header.js';
import '@polymer/app-layout/app-header-layout/app-header-layout.js';
import '@polymer/app-layout/app-scroll-effects/app-scroll-effects.js';
import '@polymer/app-layout/app-toolbar/app-toolbar.js';
import '@polymer/app-route/app-location.js';
import '@polymer/app-route/app-route.js';
import '@polymer/iron-pages/iron-pages.js';
import '@polymer/iron-selector/iron-selector.js';
import '@polymer/paper-icon-button/paper-icon-button.js';
import './my-icons.js';
import '@polymer/paper-button/paper-button.js';


// Gesture events like tap and track generated from touch will not be
// preventable, allowing for better scrolling performance.
setPassiveTouchGestures(true);

// Set Polymer's root path to the same value we passed to our service worker
// in `index.html`.
setRootPath(MyAppGlobals.rootPath);


//Child Class inheritance with POlymer parent class
class MyApp extends PolymerElement {
  // HTML Templates Starts --- Using Bootstrap 4
  static get template() {
    return html`
      <style>
        :host {
          --app-primary-color: #4285f4;
          --app-secondary-color: black;

          display: block;
        }
        
        
        app-drawer{}

          app-drawer {
            --app-drawer-content-container: {
              background: #ab8ff6;
          background: linear-gradient(90deg, #6fdaf7 0%, #b0caef 35%, #d9cfff 100%);
            }
          }

        app-header {
          color: #fff;
          background-color: var(--app-primary-color);
        }

        app-header paper-icon-button {
          --paper-icon-button-ink-color: white;
        }

        .drawer-list {
          margin: 0 20px;
        }

        .drawer-list a {
          display: block;
          padding: 0 16px;
          text-decoration: none;
          color: var(--app-secondary-color);
          line-height: 40px;
        }
        .drawer-list a.iron-selected {
          color: black;
    font-weight: bold;
    border-bottom: 1px solid #000;
    font-size: 20px;
        }
      </style>
      <!-- App Route For Navigation Purpose  -->
      <app-location route="{{route}}" query-params="{{queryParams}}  data="{{routeData}}" url-space-regex="^[[rootPath]]">
      </app-location>

      <app-route route="{{route}}" pattern="[[rootPath]]:page" data="{{routeData}}" tail="{{subroute}}">
      </app-route>
      <!-- Navigation BUttons And Links  -->
      <app-drawer-layout fullbleed="" narrow="{{narrow}}" class="drawer_c1">
        <!-- Drawer content -->
        <app-drawer id="drawer" slot="drawer" swipe-open="[[narrow]]" class="drawer_c2">
          <app-toolbar>Menu</app-toolbar>
          <iron-selector selected="[[page]]" attr-for-selected="name" class="drawer-list drawer_c3" role="navigation">
            <a name="product-list" href="[[rootPath]]product-list">All Products</a>
            <a name="fashion-list" href="[[rootPath]]fashion-list">Fashion</a>
            <a name="footwear-list" href="[[rootPath]]footwear-list">Footwears</a>
            <a name="sports-list" href="[[rootPath]]sports-list">Sports</a>
          </iron-selector>
        </app-drawer>

        <!-- Main content -->
        <app-header-layout has-scrolling-region="">
          <app-header slot="header" condenses="" reveals="" effects="waterfall">
            <app-toolbar>
              <paper-icon-button icon="my-icons:menu" drawer-toggle=""></paper-icon-button>
              <div main-title="">Welcome To E-Commerce</div>
            </app-toolbar>
          </app-header>

          <!-- Selected page Value for Navigate routing  -->
          <iron-pages selected="[[page]]" attr-for-selected="name" role="main">
            <login-page name="login-page"></login-page>
            <product-list name="product-list"></product-list>
            <fashion-list name="fashion-list"></fashion-list>
            <footwear-list name="footwear-list"></footwear-list>
            <sports-list name="sports-list"></sports-list>
            <my-view404 name="view404"></my-view404>
            <product-details name="product-details"></product-details>
            <product-detailsfoot name="product-detailsfoot"></product-detailsfoot>
            <product-detailssport name="product-detailssport"></product-detailssport>
            <add-cart name="add-cart"></add-cart>
            <add-cartfoot name="add-cartfoot"></add-cartfoot>
            <add-cartsport name="add-cartsport"></add-cartsport>
          </iron-pages>
        </app-header-layout>
      </app-drawer-layout>
    `;
  }

  // Set Properties For Routing and navigation
  static get properties() {
    return {
      page: {
        type: String,
        reflectToAttribute: true,
        observer: '_pageChanged',
        notify:true,
      },

    };
  }

  // list of its dependents
  static get observers() {
    return [
      '_routePageChanged(routeData.page)',
      '_viewChanged(routeData.view)'
    ];
  }

  _routePageChanged(page) {
     // Show the corresponding page according to the route.
     //
     // If no page was found in the route data, page will be an empty string.
     // Show 'view1' in that case. And if the page doesn't exist, show 'view404'.
    if (!page) {
      this.page = 'login-page';
    } else if (['login-page', 'product-list', 'fashion-list','footwear-list','sports-list','product-details','add-cart','product-detailsfoot','add-cartfoot','add-cartsport','product-detailssport'].indexOf(page) !== -1) {
      this.page = page;
    } else {
      this.page = 'view404';
    }

    // Close a non-persistent drawer when the page & route are changed.
    if (!this.$.drawer.persistent) {
      this.$.drawer.close();
    }
  }

  _pageChanged(page) {
    // Import the page component on demand.
    // Note: `polymer build` doesn't like string concatenation in the import
    // statement, so break it up
    // Using switch case to declare the page.
    switch (page) {
      case 'login-page':
        import('./login-page.js');
        break;
      case 'product-list':
        import('./product-list.js');
        break;
      case 'fashion-list':
        import('./fashion-list.js');
        break;
        case 'footwear-list':
        import('./footwear-list.js');
        break;
        case 'sports-list':
        import('./sports-list.js');
        break;
      case 'view404':
        import('./my-view404.js');
        break;
        case 'product-details':
          import('./product-details.js');
          break;
          case 'product-detailsfoot':
            import('./product-detailsfoot.js');
            break;  
          case 'add-cart':
          import('./add-cart.js');
          break;
          case 'add-cartfoot':
          import('./add-cartfoot.js');
          break;
          case 'add-cartsport':
          import('./add-cartsport.js');
          break;
          case 'product-detailssport':
            import('./product-detailssport.js');
            break;
        

    }
  }
}

window.customElements.define('my-app', MyApp);
