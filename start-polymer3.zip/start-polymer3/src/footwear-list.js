/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import "./header-element.js";
import "./footer-element.js";
//Declare product list array in an variable
let footwear_list =[
    {
        name : "Footwear 1",
        category:"category-footwear",
        img:"./node_modules/images/footwear_1.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
      {
        name : "Footwear 2",
        category:"category-footwear",
        img:"./node_modules/images/footwear_2.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
      {
        name : "Footwear 3",
        category:"category-footwear",
        img:"./node_modules/images/footwear_3.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
      {
        name : "Footwear 4",
        category:"category-footwear",
        img:"./node_modules/images/footwear_4.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
      {
        name : "Footwear 5",
        category:"category-footwear",
        img:"./node_modules/images/footwear_5.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
      {
        name : "Footwear 6",
        category:"category-footwear",
        img:"./node_modules/images/footwear_6.jpeg?q=50",
        link:"./product-details",
        click:"ProductDetails",
        price:"$250",
        review:"100 review",
      },
]

//Child Class inheritance with POlymer parent class
class FootwearList extends PolymerElement {
   // HTML Templates Starts --- Using Bootstrap 4
    static get template() {
        return html`
        <app-location route="{{route}}"></app-location>
        <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
        <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
        <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
        <header-element name="header" show-header="{{IncludeHeader}}"></header-element> 

      <!--- Main Products List Sections --->
        <div class="container d-flex justify-content-center mt-50 mb-50">
        <div class="row">
        <dom-repeat items="[[FootwearList]]">
        <template>
                <div class="col-md-4 mt-2">
                 <div class="card">
                        <div class="card-body">
                            <div class="card-img-actions"> 
                            <a  on-click="ProductDetails">
                             <img src="{{item.img}}" class="card-img img-fluid" width="96" height="350" alt=""> 
                             </a>
                            </div>
                        </div>
                        <div class="card-body bg-light text-center">
                            <div class="mb-2">
                                <h6 class="font-weight-semibold mb-2"> 
                                <a  on-click="ProductDetails" class="text-default mb-2" data-abc="true">{{item.name}}</a> 
                                </h6> <a  on-click="ProductDetails" class="text-muted" data-abc="true">{{item.category}}</a>
                            </div>
                            <a  on-click="ProductDetails">
                            <h3 class="mb-0 font-weight-semibold">{{item.price}}</h3>
                            <div> 
                            <i class="fa fa-star star"></i> 
                            <i class="fa fa-star star"></i> <i class="fa fa-star star"></i> 
                            <i class="fa fa-star star"></i> </div>
                            <div class="text-muted mb-3">{{item.review}}</div></a>
                            <a  on-click="ProductDetails"> 
                            <button type="button" class="btn bg-cart ">
                            <i class="fa fa-cart-plus mr-2 "></i> View More</button> 
                            </a>
                        </div>
                    </div>
                </div>
        </template>
      </dom-repeat>

        </div>
    </div>

    <footer-element name="Footer" show-Footer="{{IncludeFooter}}"></footer-element> 

   
        `}
        // Set Properties For listing the product list in page 
        static get properties() {
            return {
              FootwearList: {
                type: Array,
                value:footwear_list,
                notify:true,
              },
              IncludeHeader: {
                type:  Boolean,
                value: false,
                notify: true
              },
              IncludeFooter: {
                type:  Boolean,
                value: false,
                notify: true
              },
            };
          }
//Onclick Actions to navigate the page 
        ProductDetails(e) {
          //window.location.href='b.html#id='+a.id+'&src='+a.src;
          //alert(JSON.stringify(fashion_list[e.model.__data.index]));
          let selectedItemIdx=e.model.__data.index
          //const pro = this.FashionList[e.model.__data.index];
          //  this.productOne = e.model.__data.index;
          //  console.log(pro);
          this.set('route.path', '/product-detailsfoot/'+selectedItemIdx);
        }
        
        Fashion() {
            this.set('route.path', '/fashion-list');
        }
        Footwears() {
            this.set('route.path', '/footwear-list');
        }
        Sports() {
            this.set('route.path', '/mobile-list'); 
        }
}

window.customElements.define('footwear-list', FootwearList);