/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import "./header-element.js";
import "./footer-element.js";

//Declare product list array in an variable
let fashion_list =
[
  {
    name: "Fashion Dress 1",
    category: "category-fashion",
    img: "./node_modules/images/fashion_1.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$250",
    review: "100 review",
  },
  {
    name: "Fashion Dress 2",
    category: "category-fashion",
    img: "./node_modules/images/fashion_2.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$300",
    review: "200 review",
  },
  {
    name: "Fashion Dress 3",
    category: "category-fashion",
    img: "./node_modules/images/fashion_3.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$350",
    review: "250 review",
  },
  {
    name: "Fashion Dress 4",
    category: "category-fashion",
    img: "./node_modules/images/fashion_4.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$250",
    review: "100 review",
  },
  {
    name: "Fashion Dress 5",
    category: "category-fashion",
    img: "./node_modules/images/fashion_5.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$450",
    review: "400 review",
  },
  {
    name: "Fashion Dress 6",
    category: "category-fashion",
    img: "./node_modules/images/fashion_6.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$550",
    review: "500 review",
  },


]

//Child Class inheritance with POlymer parent class
class FashionList extends PolymerElement {
  // HTML Templates Starts --- Using Bootstrap 4
  static get template() {
    return html`
    
    <app-location route="{{route}}"></app-location>
    <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
    <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
    <header-element name="header" show-header="{{IncludeHeader}}"></header-element> 

      <!--- Main Products List Sections --->
        <div class="container d-flex justify-content-center mt-50 mb-50">
        <div class="row">
        <dom-repeat items="[[FashionList]]">
        <template>
                <div class="col-md-4 mt-2">
                 <div class="card">
                        <div class="card-body">
                            <div class="card-img-actions"> 
                            <a  on-click="ProductDetails">
                             <img src="{{item.img}}" class="card-img img-fluid" width="96" height="350" alt=""> 
                             </a>
                            </div>
                        </div>
                        <div class="card-body bg-light text-center">
                            <div class="mb-2">
                                <h6 class="font-weight-semibold mb-2"> 
                                <a  on-click="ProductDetails" class="text-default mb-2" data-abc="true">{{item.name}}</a> 
                                </h6> <a  on-click="ProductDetails" class="text-muted" data-abc="true">{{item.category}}</a>
                            </div>
                            <a  on-click="ProductDetails">
                            <h3 class="mb-0 font-weight-semibold">{{item.price}}</h3>
                            <div> 
                            <i class="fa fa-star star"></i> 
                            <i class="fa fa-star star"></i> <i class="fa fa-star star"></i> 
                            <i class="fa fa-star star"></i> </div>
                            <div class="text-muted mb-3">{{item.review}}</div></a>
                            <a  on-click="ProductDetails"> 
                            <button type="button" class="btn bg-cart ">
                            <i class="fa fa-cart-plus mr-2 "></i> View More</button> 
                            </a>
                        </div>
                    </div>
                </div>
        </template>
      </dom-repeat>
        </div>
    </div>
    <footer-element name="Footer" show-Footer="{{IncludeFooter}}"></footer-element> 
   
        `}
// Set Properties For listing the product list in page 
  static get properties() {
    return {
      FashionList: {
        type: Array,
        value: fashion_list,
        notify: true,
      },
      productOne: {
        type: Number,
        observer: "_testPro",
        notify: true,
      },
      IncludeHeader: {
        type:  Boolean,
        value: false,
        notify: true
      },
      IncludeFooter: {
        type:  Boolean,
        value: false,
        notify: true
      },
    };
  }
  _testPro(e) {
    console.log(1);
  }
//Onclick Actions to navigate the page 
  ProductDetails(e) {
    //window.location.href='b.html#id='+a.id+'&src='+a.src;
    //alert(JSON.stringify(fashion_list[e.model.__data.index]));
    let selectedItemIdx=e.model.__data.index
    //const pro = this.FashionList[e.model.__data.index];
    //  this.productOne = e.model.__data.index;
    //  console.log(pro);
    this.set('route.path', '/product-details/'+selectedItemIdx);
  }
  Fashion() {
    this.set('route.path', '/fashion-list');
  }
  Footwears() {
    this.set('route.path', '/footwear-list');
  }
  Sports() {
    this.set('route.path', '/mobile-list');
  }


}

window.customElements.define('fashion-list', FashionList);