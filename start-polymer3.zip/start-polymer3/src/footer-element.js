/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

// Import statements in Polymer 3.0 can now use package names.
// polymer-element.js now exports PolymerElement instead of Element,
// so no need to change the symbol. 
import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

class FooterElement extends PolymerElement {
  static get template () {
    
    // Template getter must return an instance of HTMLTemplateElement.
    // The html helper function makes this easy.
    return html`
    <app-location route="{{route}}"></app-location>
    <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
    <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
    
    <!--- Footer Sections --->
    <footer class="section footer-classic context-dark bg-image footer">
    <div class="container">
      <div class="row row-30">
        <div class="col-md-4 col-xl-5">
          <div class="pr-xl-4">
          <h2 style="color: #FFF;text-align: left;"> E-Commerce </h2>
            <p style="text-align: left;">We are an award-winning creative agency, dedicated to the best result in web design, promotion, business consulting, and marketing.</p>
            <!-- Rights-->
            <p class="rights" style="text-align: left;color: #000;">
              <span>©  </span><span class="copyright-year">2020</span><span> 
              </span><span>E-Commerce</span><span>. </span><span>All Rights Reserved.</span>
            </p>
          </div>
        </div>
        <div class="col-md-4" style="text-align: left;">
          <h5 style="color:#FFF;">Contacts</h5>
          <dl class="contact-list">
            <dt style="font-weight: bold;">Address:</dt>
            <dd>798 South Park Avenue, Jaipur, Raj</dd>
          </dl>
          <dl class="contact-list">
            <dt style="font-weight: bold;">E-Mail Us:</dt>
            <dd><a style="color: #000;">e-commerce@gmail.com</a></dd>
          </dl>
          <dl class="contact-list">
            <dt>Contact:</dt>
            <dd>+91 9876543210, +91 9638527410
            </dd>
          </dl>
        </div>
        <div class="col-md-4 col-xl-3" style="text-align: left;">
          <h5 style="color: #FFF;">Links</h5>
          <ul class="nav-list">
            <li><a style="color: #000;">All Products</a></li>
            <li><a style="color: #000;">Fashion</a></li>
            <li><a style="color: #000;">Footwears</a></li>
            <li><a style="color: #000;">Sports</a></li>
            <li><a style="color: #000;">Pricing</a></li>
          </ul>
        </div>
      </div>
    </div>
    <div class="row no-gutters social-container">
      <div class="col" style="border: 2px solid #FFF;padding: 10px;margin: 5px;background: #ffffff26;">
        <a class="social-inner"><span class="icon mdi mdi-facebook"></span>
        <span style="font-size: 14px;color: #FFF;font-weight: bold;letter-spacing: 2px;">Facebook</span></a>
      </div>
      <div class="col" style="border: 2px solid #FFF;padding: 10px;margin: 5px;background: #ffffff26;">
       <a class="social-inner"><span class="icon mdi mdi-instagram"></span>
       <span style="font-size: 14px;color: #FFF;font-weight: bold;letter-spacing: 2px;">Instagram</span></a>
      </div>
      <div class="col" style="border: 2px solid #FFF;padding: 10px;margin: 5px;background: #ffffff26;">
       <a class="social-inner"><span class="icon mdi mdi-twitter"></span>
       <span style="font-size: 14px;color: #FFF;font-weight: bold;letter-spacing: 2px;">Twitter</span></a>
      </div>
      <div class="col" style="border: 2px solid #FFF;padding: 10px;margin: 5px;background: #ffffff26;">
       <a class="social-inner"><span class="icon mdi mdi-youtube-play"></span>
       <span style="font-size: 14px;color: #FFF;font-weight: bold;letter-spacing: 2px;">Google</span></a>
      </div>
    </div>
  </footer>
    `;
  }
}

// Register the element with the browser.
customElements.define('footer-element', FooterElement);
