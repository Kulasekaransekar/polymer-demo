/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import "./header-element.js";
import "./footer-element.js";
import "./productall-element.js";
//Child Class inheritance with POlymer parent class
class ProductList extends PolymerElement {
   // HTML Templates Starts --- Using Bootstrap 4
    static get template() {
        return html`
        <app-location route="{{route}}"></app-location>
        <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
        <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
        <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
        <header-element name="header" show-header="{{IncludeHeader}}"></header-element> 
        <productall-element name="header" show-header="{{IncludeProductAll}}"></productall-element> 
        <footer-element name="Footer" show-Footer="{{IncludeFooter}}"></footer-element> 
        `}
        // Set Properties For listing the product list in page 
        static get properties() {
            return {

              IncludeHeader: {
                type:  Boolean,
                value: false,
                notify: true
              },
              IncludeFooter: {
                type:  Boolean,
                value: false,
                notify: true
              },
              IncludeProductAll: {
                type:  Boolean,
                value: false,
                notify: true
              }
            };
          }

        //Onclick Actions to navigate the page.

        Fashion() {
            this.set('route.path', '/fashion-list');
        }
        Footwears() {
            this.set('route.path', '/footwear-list');
        }
        Sports() {
            this.set('route.path', '/sports-list'); 
        }

    
}

window.customElements.define('product-list', ProductList);