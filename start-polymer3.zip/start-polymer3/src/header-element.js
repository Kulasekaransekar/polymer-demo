/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

// Import statements in Polymer 3.0 can now use package names.
// polymer-element.js now exports PolymerElement instead of Element,
// so no need to change the symbol. 
import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

class HeaderElement extends PolymerElement {
  static get template () {
    
    // Template getter must return an instance of HTMLTemplateElement.
    // The html helper function makes this easy.
    return html`
    <app-location route="{{route}}"></app-location>
    <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
    <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>

    <!--- Header Sections --->
    <header>
    <div class="header">
      <h2>List Of Category</h2>
      <a href="./" on-click="Logout"><li class="head_li_c1 btn btn-light" >Logout</li></a>
      <h2 class="head_c1">
        <ul class="head_ul_c1">
        <a href="./fashion-list" on-click="Fashion"><li class="head_li_c1">Fashion</li></a>
        <a href="./footwear-list" on-click="Footwears"><li class="head_li_c1">Footwears</li></a>
        <a href="./sports-list" on-click="Sports"><li class="head_li_c1">Sports</li></a>
        </ul>
      </h2>
    </div>
  </header>
    `;
  }
}

// Register the element with the browser.
customElements.define('header-element', HeaderElement);
