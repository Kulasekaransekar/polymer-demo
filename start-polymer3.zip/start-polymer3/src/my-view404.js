/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

class MyView404 extends PolymerElement {
  static get template() {
    return html`
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="node_modules/bootstrap/dist/css/style_v1.css">
    <script src="node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
      <style>
        :host {
          display: block;

          padding: 10px 20px;
        }
        .f_l{float:left;}
      </style>

      <div class="container">
      <div class="row">

      <div class="col-md-6 mt-2 f_l">
        <div>
        <img src="https://pyxis.nymag.com/v1/imgs/d67/377/dc02b103fe29d8f6a3f9fb287b75bdb552-19-inside-out-cry.rsquare.w700.jpg" height="" width=""/>
        </div>
      </div>
      <div class="col-md-6 mt-2 f_l">
        <h1 style="padding: 10px;text-align: center;">Oops you hit a 404. </h1>
        <h1 style="padding: 10px;font-size: 25px;text-align: center;background: #003ea1;color: #FFF;"> 
        <a style="color: #FFF;" href="[[rootPath]]">Click Here To Go Your Home</a>
        </h1>
      </div>

      </div>
        </div>
      
    `;
  }
}

window.customElements.define('my-view404', MyView404);
