/**
 * @license
 * Copyright (c) 2018 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

// Import statements in Polymer 3.0 can now use package names.
// polymer-element.js now exports PolymerElement instead of Element,
// so no need to change the symbol. 
import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

//Declare product list array in an variable
let product_alllist =[
  {
    name : "FASHIONS",
    category:"category-fashion",
    link:"./fashion-list",
    click:"Fashion",
    img:"./node_modules/images/fashion_1.jpeg?q=50",
  },
  {
    name : "FOOTWEARS",
    category:"category-footwear",
    link:"./footwear-list",
    click:"Footwears",
    img:"./node_modules/images/footwear_1.jpeg?q=50",
  },
  {
    name : "SPORTS",
    category:"category-sports",
    link:"./sports-list",
    click:"Sports",
    img:"./node_modules/images/sports_1.jpeg??q=50",
  },
]
class ProductAllElement extends PolymerElement {
  static get template () {
    // Template getter must return an instance of HTMLTemplateElement.
    // The html helper function makes this easy.
    return html`
    <app-location route="{{route}}"></app-location>
    <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
    <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
    <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
    <!--- Main Products List Sections --->
    <div class="container d-flex justify-content-center mt-50 mb-50">
    <div class="row">
    <dom-repeat items="[[ProductAllList]]">
    <template>
            <div class="col-md-4 mt-2">
             <div class="card">
                    <div class="card-body">
                        <div class="card-img-actions"> 
                        <a href="{{item.link}}" on-click="{{item.click}}">
                         <img src="{{item.img}}" class="card-img img-fluid" width="96" height="350" alt=""> 
                         </a>
                        </div>
                    </div>
                    <div class="card-body bg-light text-center">
                        <div class="mb-2">
                            <h6 class="font-weight-semibold mb-2"> 
                            <a href="{{item.link}}" on-click="{{item.click}}" class="text-default mb-2" data-abc="true">{{item.name}}</a> 
                            </h6> <a href="{{item.link}}" on-click="{{item.click}}" class="text-muted" data-abc="true">{{item.category}}</a>
                        </div>
                        <a href="{{item.link}}" on-click="{{item.click}}"> 
                        <button type="button" class="btn bg-cart ">
                        <i class="fa fa-cart-plus mr-2 "></i> View More</button> 
                        </a>
                    </div>
                </div>
            </div>
    </template>
  </dom-repeat>
    </div>
</div>



    `;
  }
        

  
  
  
  // Set Properties For listing the product list in page 
        static get properties() {
          return {
            ProductAllList: {
              type: Array,
              value:product_alllist,
              notify:true,
            },
          };
        }

      //Onclick Actions to navigate the page.

      Fashion() {
          this.set('route.path', '/fashion-list');
      }
      Footwears() {
          this.set('route.path', '/footwear-list');
      }
      Sports() {
          this.set('route.path', '/sports-list'); 
      }


}

// Register the element with the browser.
customElements.define('productall-element', ProductAllElement);
