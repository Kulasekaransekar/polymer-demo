/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import "./header-element.js";
import "./footer-element.js";


//Declare product list array in an variable
let sports_list =[
  {
      name : "Sports 1",
      category:"category-footwear",
      img:"./node_modules/images/sports_1.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
    {
      name : "Sports 2",
      category:"category-footwear",
      img:"./node_modules/images/sports_2.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
    {
      name : "Sports 3",
      category:"category-footwear",
      img:"./node_modules/images/sports_3.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
    {
      name : "Sports 4",
      category:"category-footwear",
      img:"./node_modules/images/sports_4.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
    {
      name : "Sports 5",
      category:"category-footwear",
      img:"./node_modules/images/sports_5.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
    {
      name : "Sports 6",
      category:"category-footwear",
      img:"./node_modules/images/sports_6.jpeg??q=50",
      link:"./product-details",
      click:"ProductDetails",
      price:"$250",
      review:"100 review",
    },
]
//Child Class inheritance with POlymer parent class
class AddCartFootSport extends PolymerElement {
  // HTML Templates Starts --- Using Bootstrap 4
    static get template() {
        return html`
        <app-location route="{{route}}"></app-location>
        <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
        <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
        <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
        <header-element name="header" show-header="{{IncludeHeader}}"></header-element> 

      <!--- Main Products List Sections --->
        <div class="container d-flex justify-content-center mt-50 mb-50">
        <div class="row">
        <div class="col-md-12 float-left mt-2 ">
            <button type="button" class="btn btn-warning" on-click="Continue">Continue Shopping</button>
        </div> 
        <template is="dom-repeat" items="{{ SportsList }}">
        <div class="mt-2 " id="cartvalue">
            <div class="col-md-12 float-left" style="padding: 20px;border-radius: 10px;background-color: #9b99f4;background: linear-gradient(90deg, #e5f7ff 0%, #ecebff 35%, #e5f7ff 100%);">
                <div class="col-md-3 float-left">
                <img width="50%" height="150px" src="[[item.img]]" />
                </div> 
                <div class="col-md-3 float-left">
                    <h2 style="font-size: 20px;vertical-align: middle;line-height: 60px;">Name : [[item.name]]</h2>
                    <h2 style="font-size: 20px;vertical-align: middle;line-height: 50px;">category : [[item.category]]</h2>
                </div> 
                <div class="col-md-3 float-left">
                    <h2 style="font-size: 20px;vertical-align: middle;line-height: 60px;">Price : [[item.price]]</h2>
                    <h2 style="font-size: 20px;vertical-align: middle;line-height: 50px;">100 review</h2>
                </div> 
                <div class="col-md-3 float-left">
                    <button type="button" class="btn btn-danger" on-click="PlaceOrder" style="margin-top: 20%;">Place Order</button>
                </div> 

            </div>        
        </div> 
        </template>

        </div>
    </div>


 
    <!--- Footer Sections --->
    <footer-element name="Footer" show-Footer="{{IncludeFooter}}"></footer-element> 

        `}
// Set Properties For listing the product list in page
static get properties() {
        var loc=window.location.href
        var splitedLoc=loc.split('/')
        var idx=splitedLoc[splitedLoc.length-1]
        var selectedItemsports = sports_list[idx]
        //var selectedItemfootwear = footwear_list[idx]
        //var selectedItemsports = sports_list[idx]
            return {
              SportsList: {
                type: Array,
                  value() {
                    return [
                        selectedItemsports,
                    ];
                  }
              },
              IncludeHeader: {
                type:  Boolean,
                value: false,
                notify: true
              },
              IncludeFooter: {
                type:  Boolean,
                value: false,
                notify: true
              },
            };
          }
//Onclick Actions to navigate the page 
        PlaceOrder() {
          alert("Thanks For Shoping");
          this.set('route.path', '/product-list');
       }
        Continue(){
            this.set('route.path', '/product-list');
        }
        Fashion() {
            this.set('route.path', '/fashion-list');
        }
        Footwears() {
            this.set('route.path', '/footwear-list');
        }
        Sports() {
            this.set('route.path', '/mobile-list'); 
        }

    
}

window.customElements.define('add-cartsport', AddCartFootSport);