/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';

let fashion_list =[
    {
      name: "Fashion Dress 1",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/ke4kjgw0-0/t-shirt/r/w/x/s-101-try-this-original-imafuvgbqkvhtmwp.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$250",
      review: "100 review",
    },
    {
      name: "Fashion Dress 2",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/kdbzqfk0/t-shirt/l/l/a/l-tbt-try-this-original-imafu9kkhptg7xuh.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$300",
      review: "200 review",
    },
    {
      name: "Fashion Dress 3",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/katyzrk0/t-shirt/z/y/w/xxl-ds01-try-this-original-imafsb8ju76qqhqw.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$350",
      review: "250 review",
    },
    {
      name: "Fashion Dress 4",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/khdqnbk0/t-shirt/y/j/u/m-fc4175-fastcolors-original-imafxettkgtjrzcx.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$250",
      review: "100 review",
    },
    {
      name: "Fashion Dress 5",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/katyzrk0/t-shirt/z/y/w/xxl-ds01-try-this-original-imafsb8ju76qqhqw.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$450",
      review: "400 review",
    },
    {
      name: "Fashion Dress 6",
      category: "category-fashion",
      img: "https://rukminim1.flixcart.com/image/580/696/kgiaykw0-0/t-shirt/r/m/k/l-red-togo-try-this-original-imafwqkzkwmk4xnk.jpeg?q=50",
      link: "./product-details",
      click: "ProductDetails",
      price: "$550",
      review: "500 review",
    },
  
  
  ]

class ProductDetails extends PolymerElement {
    static get template() {
        return html`
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
        <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
        <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
   
        <app-location route="{{route}}"></app-location>
        <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>

        <header>
        <div class="header">
          <h2>Welcome To E-Commerce</h2>
          <h2 class="head_c1">
            <ul class="head_ul_c1">
            <a href="./fashion-list" on-click="Fashion"><li class="head_li_c1">Fashion</li></a>
            <a href="./footwear-list" on-click="Footwears"><li class="head_li_c1">Footwears</li></a>
            <a href="./sports-list" on-click="Sports"><li class="head_li_c1">Sports</li></a>
            </ul>
          </h2>
        </div>
      </header>



      <template is="dom-repeat" items="{{FashionList}}">
      <div class="container">
      <div class="card">
     
          <div class="container-fliud">
              <div class="wrapper row">
                  <div class="preview col-md-6">
                      
                      <div class="preview-pic tab-content">
                        <div class="tab-pane active" id="pic-1">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-2">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-3">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-4">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-5">
                        <img src="[[item.img]]" /></div>
                      </div>
                      <ul class="preview-thumbnail nav nav-tabs">
                        <li class="active"><a data-target="#pic-1" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-2" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-3" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-4" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-5" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                      </ul>
                      
                  </div>
                  <div class="details col-md-6">
                      <h3 class="product-title">[[item.name]]</h3>
                      <div class="rating">
                          <div class="stars">
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star"></span>
                              <span class="fa fa-star"></span>
                          </div>
                          <span class="review-no">[[item.review]]</span>
                      </div>
                      <p class="product-description">[[item.category]]</p>
                      <h4 class="price">current price: <span>[[item.price]]</span></h4>
                      <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                      <h5 class="sizes">sizes:
                          <span class="size" data-toggle="tooltip" title="small">s</span>
                          <span class="size" data-toggle="tooltip" title="medium">m</span>
                          <span class="size" data-toggle="tooltip" title="large">l</span>
                          <span class="size" data-toggle="tooltip" title="xtra large">xl</span>
                      </h5>
                      <h5 class="colors">colors:
                          <span class="color orange not-available" data-toggle="tooltip" title="Not In store">
                          </span>
                          <span class="color green"></span>
                          <span class="color blue"></span>
                      </h5>
                      <div class="action">
                          <button class="add-to-cart btn btn-default" type="button" on-click="AddCart">add to cart</button>
                          
                      </div>
                  </div>
              </div>
          </div>
          
      </div>
  </div>
  </template>
    <footer>
    <div class="footer">
      <h2>Footer Navigations</h2>
      <h2 class="head_c1">
      <ul class="head_ul_c1">
        <a href="./fashion-list" on-click="Fashion"><li class="head_li_c1">Fashion</li></a>
        <a href="./footwear-list" on-click="Footwears"><li class="head_li_c1">Footwears</li></a>
        <a href="./sports-list" on-click="Sports"><li class="head_li_c1">Sports</li></a>
      </ul>
      </h2>
    </div>
    </footer>

   
        `}


    static get properties() {
        var loc=window.location.href
        var splitedLoc=loc.split('/')
        var idx=splitedLoc[splitedLoc.length-1]
        var selectedItem = fashion_list[idx]
        let selectdata = JSON.stringify(selectedItem)
        console.log(selectedItem);

            return {
              FashionList: {
                type: Array,
                  value() {
                    return [
                        selectedItem,
                    ];
                  }
              },
            };



          }

  

        AddCart(e) {
          alert(e.model.__data.index)
        let selectedItemIdx=e.model.__data.index
        //this.set('route.path', '/add-cart/'+selectedItemIdx);
        }
        Fashion() {
            this.set('route.path', '/fashion-list');
        }
        Footwears() {
            this.set('route.path', '/footwear-list');
        }
        Sports() {
            this.set('route.path', '/mobile-list'); 
        }

    
}

window.customElements.define('product-details', ProductDetails);