/**
 * @license
 * Copyright (c) 2016 The Polymer Project Authors. All rights reserved.
 * This code may only be used under the BSD style license found at http://polymer.github.io/LICENSE.txt
 * The complete set of authors may be found at http://polymer.github.io/AUTHORS.txt
 * The complete set of contributors may be found at http://polymer.github.io/CONTRIBUTORS.txt
 * Code distributed by Google as part of the polymer project is also
 * subject to an additional IP rights grant found at http://polymer.github.io/PATENTS.txt
 */

import { PolymerElement, html } from '@polymer/polymer/polymer-element.js';
import "./header-element.js";
import "./footer-element.js";
//Declare product list array in an variable
let fashion_list =
[
  {
    name: "Fashion Dress 1",
    category: "category-fashion",
    img: "./node_modules/images/fashion_1.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$250",
    review: "100 review",
  },
  {
    name: "Fashion Dress 2",
    category: "category-fashion",
    img: "./node_modules/images/fashion_2.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$300",
    review: "200 review",
  },
  {
    name: "Fashion Dress 3",
    category: "category-fashion",
    img: "./node_modules/images/fashion_3.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$350",
    review: "250 review",
  },
  {
    name: "Fashion Dress 4",
    category: "category-fashion",
    img: "./node_modules/images/fashion_4.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$250",
    review: "100 review",
  },
  {
    name: "Fashion Dress 5",
    category: "category-fashion",
    img: "./node_modules/images/fashion_5.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$450",
    review: "400 review",
  },
  {
    name: "Fashion Dress 6",
    category: "category-fashion",
    img: "./node_modules/images/fashion_6.jpeg?q=50",
    link: "./product-details",
    click: "ProductDetails",
    price: "$550",
    review: "500 review",
  },


]


//Child Class inheritance with POlymer parent class
class ProductDetails extends PolymerElement {
  // HTML Templates Starts --- Using Bootstrap 4
    static get template() {
        return html`
        <app-location route="{{route}}"></app-location>
        <app-route route="{{route}}" pattern="/:view" data="{{routeData}}" tail="{{subroute}}"></app-route>
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/bootstrap.min.css">
        <link rel="stylesheet" href="./node_modules/bootstrap/dist/css/style_v1.css">
        <script src="./node_modules/jquery/dist/jquery.min.js" async></script>
        <script src="./node_modules/bootstrap/dist/js/bootstrap.min.js" async></script>
        <header-element name="header" show-header="{{IncludeHeader}}"></header-element> 


      <!--- Main Products List Sections --->
      <template is="dom-repeat" items="{{ FashionList }}">
      <div class="container">
      <div class="card">
     
          <div class="container-fliud">
              <div class="wrapper row">
                  <div class="preview col-md-6">
                      
                      <div class="preview-pic tab-content">
                        <div class="tab-pane active" id="pic-1">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-2">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-3">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-4">
                        <img src="[[item.img]]" /></div>
                        <div class="tab-pane" id="pic-5">
                        <img src="[[item.img]]" /></div>
                      </div>
                      <ul class="preview-thumbnail nav nav-tabs">
                        <li class="active"><a data-target="#pic-1" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-2" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-3" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-4" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                        <li><a data-target="#pic-5" data-toggle="tab">
                        <img src="[[item.img]]" /></a></li>
                      </ul>
                      
                  </div>
                  <div class="details col-md-6">
                      <h3 class="product-title">[[item.name]]</h3>
                      <div class="rating">
                          <div class="stars">
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star checked"></span>
                              <span class="fa fa-star"></span>
                              <span class="fa fa-star"></span>
                          </div>
                          <span class="review-no">[[item.review]]</span>
                      </div>
                      <p class="product-description">[[item.category]]</p>
                      <h4 class="price">current price: <span>[[item.price]]</span></h4>
                      <p class="vote"><strong>91%</strong> of buyers enjoyed this product! <strong>(87 votes)</strong></p>
                      <h5 class="sizes">sizes:
                          <span class="size" data-toggle="tooltip" title="small">s</span>
                          <span class="size" data-toggle="tooltip" title="medium">m</span>
                          <span class="size" data-toggle="tooltip" title="large">l</span>
                          <span class="size" data-toggle="tooltip" title="xtra large">xl</span>
                      </h5>
                      <h5 class="colors">colors:
                          <span class="color orange not-available" data-toggle="tooltip" title="Not In store">
                          </span>
                          <span class="color green"></span>
                          <span class="color blue"></span>
                      </h5>
                      <div class="action">
                          <button class="add-to-cart btn btn-default" type="button" on-click="AddCart">add to cart</button>
                          
                      </div>
                  </div>
              </div>
          </div>
          
      </div>
  </div>
  </template>


  <footer-element name="Footer" show-Footer="{{IncludeFooter}}"></footer-element> 
   
        `}

// Set Properties For listing the product list in page 
    static get properties() {
        var loc=window.location.href
        var splitedLoc=loc.split('/')
        var idx=splitedLoc[splitedLoc.length-1]
        console.log(idx);
        var selectedItemfashion = fashion_list[idx]
        //footwear_list
        //sports_list
        //let selectdata = JSON.stringify(selectedItem)
        //console.log(selectedItem);
            return {
              FashionList: {
                type: Array,
                  value() {
                    return [
                        selectedItemfashion,
                    ];
                  }
              },
              IncludeHeader: {
                type:  Boolean,
                value: false,
                notify: true
              },
              IncludeFooter: {
                type:  Boolean,
                value: false,
                notify: true
              },
            };
          }

  
//Onclick Actions to navigate the page 
          AddCart() {
         // alert(selectedItemfashion.index)
         
         var locx=window.location.href
         
       var splitedLocxx=locx.split('/')
      
        var idxx=splitedLocxx[splitedLocxx.length-1]
       // alert(idxx)
          let selectedItemIdxx=idxx
       //   alert(selectedItemIdx)

         this.set('route.path', '/add-cart/'+selectedItemIdxx);
          }
        Fashion() {
            this.set('route.path', '/fashion-list');
        }
        Footwears() {
            this.set('route.path', '/footwear-list');
        }
        Sports() {
            this.set('route.path', '/mobile-list'); 
        }

    
}

window.customElements.define('product-details', ProductDetails);